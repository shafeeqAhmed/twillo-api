<?php

return [

    'twilio_sid' => env('TWILIO_SID'),
    'twilio_token' => env('TWILIO_TOKEN'),
    'front_app_url' => env('FRONT_END_APP', 'http://localhost:3000'),

];
